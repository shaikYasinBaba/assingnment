document.querySelectorAll('.quick-view-btn').forEach(button => {
    button.addEventListener('click', function() {
        const modal = document.querySelector(this.dataset.modalTarget);
        openModal(modal);
    });
});

document.querySelectorAll('.close-btn').forEach(button => {
    button.addEventListener('click', function() {
        const modal = this.closest('.modal');
        closeModal(modal);
    });
});

window.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        closeModal(event.target);
    }
});

function openModal(modal) {
    if (modal == null) return;
    modal.style.display = 'block';
}

function closeModal(modal) {
    if (modal == null) return;
    modal.style.display = 'none';
}
